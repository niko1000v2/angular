import { Component, OnInit } from '@angular/core';
import {ProductsService} from '../products.service';

@Component({
  selector: 'app-main-content',
  templateUrl: './main-content.component.html',
  styleUrls: ['./main-content.component.css']
})
export class MainContentComponent implements OnInit {

  constructor(private productService: ProductsService) { }

  ngOnInit() {
  }

  dodaj ()
  {
    this.productService.addProducts({number: 51260, name: '12412441', price: 300, vat: 23, amount: 4, img: 'tunel.png'});
  }

}
