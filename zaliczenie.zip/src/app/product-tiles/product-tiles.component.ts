import { Component, OnInit } from '@angular/core';
import {ProductsService} from '../products.service';

@Component({
  selector: 'app-product-tiles',
  templateUrl: './product-tiles.component.html',
  styleUrls: ['./product-tiles.component.css']
})
export class ProductTilesComponent implements OnInit {

  private products: Product[];

  constructor(private productService: ProductsService) { }

  ngOnInit() {
    this.products = this.productService.getProducts();

  }
  dodaj () {
    this.productService.addProducts({number: 51260, name: '12412441', price: 300, vat: 23, amount: 4, img: 'tunel.png'});
  }

  usun() {
    this.productService.delete();
  }



}

export class Product {

   number: number;
   name: string;
   price: number;
   vat: number;
   amount: number;
   img: string;



  constructor(number: number, name: string, price: number, vat: number, amount: number, img: string) {
    this.number = number;
    this.name = name;
    this.price = price;
    this.vat = vat;
    this.amount = amount;
    this.img = img;

  }
}
