import {Component, Input, OnInit} from '@angular/core';
import {ProductsService} from '../products.service';

@Component({
  selector: 'app-product-tile',
  templateUrl: './product-tile.component.html',
  styleUrls: ['./product-tile.component.css']
})
export class ProductTileComponent implements OnInit {

  @Input() number;
  @Input() name;
  @Input() price ;
  @Input() vat;
  @Input() amount;
  @Input() img;

  constructor() { }

  ngOnInit() {
  }


}


