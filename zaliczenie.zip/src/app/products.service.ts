import { Injectable } from '@angular/core';
import {Product} from './product-tiles/product-tiles.component';

@Injectable({
  providedIn: 'root'
})
export class ProductsService {

  public products: Product[];

  constructor() {
    this.products = [
      new Product(12321, 'Purizon Adult dla kota, kurczak i ryba', 100, 8, 127, 'karma_kot.jpg'),
      new Product(73455, 'Greenwoods żwirek roślinny ', 50, 23, 32, 'zwirek.png'),
      new Product(51233, 'Greenwoods pokarm dla świnek morskich', 80, 0, 9, 'karma_swinka.png'),
      new Product(51260, 'Trixie tunel wiklinowy dla małych zwierząt', 300, 23, 4, 'tunel.png'),

    ];
  }

  getProducts(): Product[] {
    return this.products;
  }

  addProducts(product: Product): void {
    this.products.push(product);
  }

  delete(): void {
    this.products.splice(1, 1);
  }

}

